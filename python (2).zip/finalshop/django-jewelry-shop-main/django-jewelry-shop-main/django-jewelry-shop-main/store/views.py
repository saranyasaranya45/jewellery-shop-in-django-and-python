from django.contrib.auth.models import User
from django.shortcuts import redirect, render, get_object_or_404
from django.contrib import messages
from django.contrib.auth import logout, authenticate, login
from django.views import View
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.contrib.auth.forms import AuthenticationForm
from django.http import HttpResponse
from datetime import datetime
import decimal
from store.models import Address, Cart, Category, Order, Product, Post
from .forms import RegistrationForm, AddressForm
from .models import Order
from django.shortcuts import render
from django.contrib.auth.models import User
from .models import Profile


# Logout View
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return render(request, 'store/logout.html')

#from django.core.mail import send_mail
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.shortcuts import redirect, render
from django.conf import settings

def admin_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.is_staff:
                login(request, user)
                messages.success(request, "You are now logged in as an admin.")

                # Send an email notification
                send_mail(
                    subject="Admin Login Notification",
                    message="An admin has logged in successfully.",
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=['saranyasaranya53481@gmail.com'],  # Replace with the actual recipient's email
                    fail_silently=False,
                )

                return redirect('store:home')
            else:
                messages.error(request, "Invalid username or password, or not an admin.")
    else:
        form = AuthenticationForm()
    return render(request, 'store/admin_login.html', {'form': form})
from django.core.mail import send_mail
from django.conf import settings

send_mail(
    subject="Login Email",
    message="Admin login successfully done by django python",
    from_email=settings.DEFAULT_FROM_EMAIL,
    recipient_list=['saranyasaranya53481@gmail.com'],
    fail_silently=False,
)


# Home View
def home(request):
    categories = Category.objects.filter(is_active=True, is_featured=True)[:3]
    products = Product.objects.filter(is_active=True, is_featured=True)[:8]
    context = {
        'categories': categories,
        'products': products,
    }
    return render(request, 'store/index.html', context)

# Blog View
def blog_view(request):
    return render(request, 'store/blog.html')


# Handle Contact Submission
from django.shortcuts import redirect
from django.http import HttpResponse
from django.core.mail import send_mail
from django.conf import settings

def submit_contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        # Send email notification with contact form details
        send_mail(
            subject=f"New Contact Form Submission from {name}",
            message=f"Name: {name}\nEmail: {email}\nMessage: {message}",
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=['saranyasaranya53481@gmail.com'],  # Replace with actual recipient's email
            fail_silently=False,
        )

        return redirect('store:success')
    return HttpResponse("Invalid request", status=400)

# Success View
def success_view(request):
    return render(request, 'store/success.html')

# Product Detail View
def detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    related_products = Product.objects.exclude(id=product.id).filter(is_active=True, category=product.category)
    context = {
        'product': product,
        'related_products': related_products,
    }
    return render(request, 'store/detail.html', context)

# All Categories View
def all_categories(request):
    categories = Category.objects.filter(is_active=True)
    return render(request, 'store/categories.html', {'categories': categories})

# Category Products View
def category_products(request, slug):
    category = get_object_or_404(Category, slug=slug)
    products = Product.objects.filter(is_active=True, category=category)
    context = {
        'category': category,
        'products': products,
    }
    return render(request, 'store/category_products.html', context)

# User Registration View (Class-based)
class RegistrationView(View):
    def get(self, request):
        form = RegistrationForm()
        return render(request, 'account/register.html', {'form': form})

    def post(self, request):
        form = RegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, "Congratulations! Registration Successful!")
            form.save()
        return render(request, 'account/register.html', {'form': form})

# User Profile View
@login_required
def profile(request):
    addresses = Address.objects.filter(user=request.user)
    orders = Order.objects.filter(user=request.user)
    return render(request, 'account/profile.html', {'addresses': addresses, 'orders': orders})

# Address Management View (Class-based)
@method_decorator(login_required, name='dispatch')
class AddressView(View):
    def get(self, request):
        form = AddressForm()
        return render(request, 'account/add_address.html', {'form': form})

    def post(self, request):
        form = AddressForm(request.POST)
        if form.is_valid():
            user = request.user
            reg = Address(
                user=user,
                locality=form.cleaned_data['locality'],
                city=form.cleaned_data['city'],
                state=form.cleaned_data['state'],
            )
            reg.save()
            messages.success(request, "New Address Added Successfully.")
        return redirect('store:profile')

# Remove Address
@login_required
def remove_address(request, id):
    a = get_object_or_404(Address, user=request.user, id=id)
    a.delete()
    messages.success(request, "Address removed.")
    return redirect('store:profile')

# Add to Cart
@login_required
def add_to_cart(request):
    user = request.user
    product_id = request.GET.get('prod_id')
    product = get_object_or_404(Product, id=product_id)
    item_already_in_cart = Cart.objects.filter(product=product_id, user=user)
    if item_already_in_cart.exists():
        cp = item_already_in_cart.first()
        cp.quantity += 1
        cp.save()
    else:
        Cart(user=user, product=product).save()
    return redirect('store:cart')

# Cart View
from django.shortcuts import render, redirect
from .models import Cart, Order, Address
from django.contrib.auth.decorators import login_required
import decimal
from django.core.mail import send_mail
from django.conf import settings
from .models import Address, Cart, Order  # Add Order if you have an Order model

@login_required
def cart(request):
    user = request.user
    cart_products = Cart.objects.filter(user=user)

    # Calculate total amount for the cart
    amount = sum(p.quantity * p.product.price for p in cart_products)
    shipping_amount = decimal.Decimal(10)
    total_amount = amount + shipping_amount

    # Get all addresses for the user
    addresses = Address.objects.filter(user=user)

    # Handle checkout form submission
    if request.method == 'POST':
        address_id = request.POST.get('address')  # Assuming the user selects an address from a dropdown
        address = Address.objects.get(id=address_id)

        # Create orders for each product in the cart
        for cart_item in cart_products:
            # Ensure the order is saved with all required fields
            order = Order.objects.create(
                user=user,
                address=address,
                product=cart_item.product,
                quantity=cart_item.quantity,
                status="Pending",  # Set a valid status like "Pending"
                ordered_date=datetime.now(),
            )

        # Clear the cart after creating orders
        cart_products.delete()

        # Send an email confirmation to the user
        subject = 'Order Confirmation'
        message = f'Dear {user.first_name},\n\nYour order has been successfully placed. You ordered:\n'
        for cart_item in cart_products:
            message += f'- {cart_item.product.name} (x{cart_item.quantity})\n'
        message += f'\nTotal Amount: ${total_amount}\n\nThank you for shopping with us!'

        send_mail(
            subject=subject,
            message=message,
            from_email=settings.EMAIL_HOST_USER,
            recipient_list=['saranyasaranya53481@gmail.com'],  # Send to the user's email
        )

        return redirect('store:orders')  # Redirect to the orders page after placing the order

    # Render the cart page with the current cart items, total amount, etc.
    context = {
        'cart_products': cart_products,
        'amount': amount,
        'shipping_amount': shipping_amount,
        'total_amount': total_amount,
        'addresses': addresses,
    }
    return render(request, 'store/cart.html', context)


# Remove Cart Item
@login_required
def remove_cart(request, cart_id):
    c = get_object_or_404(Cart, id=cart_id)
    c.delete()
    messages.success(request, "Product removed from Cart.")
    return redirect('store:cart')

# Increment Cart Item Quantity
@login_required
def plus_cart(request, cart_id):
    cp = get_object_or_404(Cart, id=cart_id)
    cp.quantity += 1
    cp.save()
    return redirect('store:cart')

# Decrement Cart Item Quantity
@login_required
def minus_cart(request, cart_id):
    cp = get_object_or_404(Cart, id=cart_id)
    if cp.quantity == 1:
        cp.delete()
    else:
        cp.quantity -= 1
        cp.save()
    return redirect('store:cart')

#--------------------------------------CHANGED CODE-----------------------------------



@login_required
def order_confirmation(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    return render(request, 'store/order_confirmation.html', {'order': order})

@login_required
def payment(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)

    if request.method == 'POST':
        # Handle payment logic here (integration with payment gateway)
        # For now, we'll assume the payment is successful
        order.status = 'Paid'
        order.save()

        # Redirect to the order confirmation page
        return redirect('store:order_confirmation', order_id=order.id)

    # Render payment form with order details
    return render(request, 'store/payment.html', {'order': order})

#-----------------------------CHANGED CODE--------------------------------------        

@login_required
def orders(request):
    # Fetch all orders for the current logged-in user, ordered by the most recent first
    all_orders = Order.objects.filter(user=request.user).order_by('-ordered_date')
    
    # Render the orders page with the list of orders
    return render(request, 'store/orders.html', {'orders': all_orders})


# Shop View
def shop(request):
    return render(request, 'store/shop.html')

# Test View
def test(request):
    return render(request, 'store/test.html')


from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.conf import settings
from .forms import ContactForm

def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            # Save the form data to the database
            form.save()

            # Send email to the host email
            send_mail(
                f"New Contact Us Message from {form.cleaned_data['name']}",
                form.cleaned_data['message'],
                form.cleaned_data['email'],  # sender's email
                [settings.HOST_EMAIL],  # recipient's email (host's email)
                fail_silently=False,
            )

            return redirect('store:thank-you')  # Redirect to a thank you page
    else:
        form = ContactForm()

    return render(request, 'store/contact.html', {'form': form})


def thank_you(request):
    return render(request, 'thank_you.html')


from django.core.mail import send_mail
from django.conf import settings
from django.shortcuts import render, redirect
from django.http import Http404
from .models import Address, Cart
from django.contrib.sites.shortcuts import get_current_site
def checkout(request):
    if request.method == 'POST':
        address_id = request.POST.get('address')
        try:
            address = Address.objects.get(id=address_id)
        except Address.DoesNotExist:
            raise Http404("No Address matches the given query.")

        cart_items = Cart.objects.filter(user=request.user)
        if not cart_items.exists():
            return redirect('cart')  # Redirect to cart if empty

        total_amount = sum(item.total_price for item in cart_items)

        # Save the order
        order = Order.objects.create(
            user=request.user,
            address=address,
            total_amount=total_amount,
        )

        # Add items to the order
        for item in cart_items:
            order.items.create(
                product=item.product,
                quantity=item.quantity,
                price=item.total_price,
            )
        
        # Clear the cart
        cart_items.delete()

        # Prepare and send email
        email_subject = 'Your Order Confirmation'
        email_body = f"Hello {request.user.first_name},\n\n" \
                     f"Thank you for your order. Here are the details:\n\n"
        for item in cart_items:
            email_body += f"- {item.product_name} (Quantity: {item.quantity}) - ${item.total_price}\n"
        email_body += f"\nTotal Amount: ${total_amount}\n\n"
        email_body += f"Shipping Address: {address.street_address}, {address.city}, {address.state}, {address.zip_code}\n"
        email_body += f"Thanks for shopping with us!\n\n" \
                      f"Best Regards,\nYour Store Team"

        send_mail(
            email_subject,
            email_body,
            settings.DEFAULT_FROM_EMAIL,
            [request.user.email],
        )

        return redirect('success')

    addresses = Address.objects.filter(user=request.user)
    return render(request, 'store/orders.html', {'addresses': addresses})
#--------------------------rating-------------------------


# views.py

from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, Review

def product_detail(request, slug):
    # Fetch the product using the slug
    product = get_object_or_404(Product, slug=slug)
    # Fetch the reviews for the product
    reviews = product.reviews.all()
    
    # Handle the POST request when the form is submitted
    if request.method == "POST":
        rating = request.POST.get('rating')
        text = request.POST.get('text')
        
        # Ensure that rating is an integer
        try:
            rating = int(rating)
        except ValueError:
            # Handle invalid rating, e.g., set a default or show an error
            rating = 1  # You can change this to handle errors as needed
            
        # Create and save the review
        review = Review(user=request.user, product=product, rating=rating, text=text)
        review.save()
        
        # Redirect back to the product detail page after saving the review
        return redirect('product_detail', slug=slug)

    # Render the product detail page with reviews
    return render(request, 'store/detail.html', {'product': product, 'reviews': reviews})

#--------------------submit------------------------------
from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, Review

def submit_review(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    
    if request.method == "POST":
        # Safely get the values using .get() method
        rating = request.POST.get('rating')
        text = request.POST.get('text')

        # Check if both fields are present
        if rating and text:
            # Create and save the review
            review = Review(user=request.user, product=product, rating=rating, text=text)
            review.save()
            # Redirect to the product detail page using the slug
            return redirect('product_detail', slug=product.slug)
        else:
            # Handle missing fields (optional error handling)
            return render(request, 'store/detail.html', {
                'product': product,
                'error': 'Please fill in all fields.'  # Show this error in the template
            })
    
    return render(request, 'store/detail.html', {'product': product})

from django.shortcuts import redirect, get_object_or_404
from .models import Product, Wishlist
import logging

logger = logging.getLogger(__name__)

def add_to_wishlist(request, product_id):
    logger.debug("Add to Wishlist View Called")  # This will log to console if configured
    product = get_object_or_404(Product, id=product_id)
    
    if request.user.is_authenticated:
        Wishlist.objects.get_or_create(user=request.user, product=product)
        return redirect('store:product-detail', slug=product.slug)
    else:
        return redirect('account:login')
        #-------------------------------------admin--------------------------------
        # store/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages

# Manage Users (Example: Listing all users)
@staff_member_required

def manage_users(request):
    users = User.objects.all()
    profiles = Profile.objects.all()
    return render(request, 'store/manage_users.html', {'users': users, 'profiles': profiles})


# Example of Deactivating a User (or any other user management action)
@staff_member_required
def deactivate_user(request, user_id):
    user = get_object_or_404(User, id=user_id)
    if user.is_active:
        user.is_active = False
        user.save()
        messages.success(request, f'User {user.username} has been deactivated.')
    else:
        messages.info(request, f'User {user.username} is already inactive.')
    return redirect('store:manage_users')

# store/views.py
from django.shortcuts import render, redirect
from django.contrib.admin.views.decorators import staff_member_required

# Custom Admin Dashboard
@staff_member_required
def custom_admin_dashboard(request):
    return render(request,'admin/custom_dashboard.html')

@staff_member_required
def manage_users(request):
    # Logic for custom user management, if needed
    return render(request, 'admin/manage_users.html')

from django.shortcuts import render
from django.http import HttpResponseForbidden
from django.contrib.auth.decorators import login_required

def dashboard(request):
    # Get data for the dashboard
    total_products = Product.objects.count()
    total_orders = Order.objects.count()
    total_reviews = Review.objects.count()
    total_users = User.objects.count()
    total_categories = Category.objects.count()

    # Pass the data to the template
    context = {
        'total_products': total_products,
        'total_orders': total_orders,
        'total_reviews': total_reviews,
        'total_users': total_users,
        'total_categories': total_categories,
    }
    return render(request, 'store/dashboard.html', context)

    from django.contrib.auth.decorators import login_required
from .models import Product, Category, Order, Review, User, Contact

# View for managing products
@login_required
def manage_products(request):
    products = Product.objects.all()
    return render(request, 'store/manage_products.html', {'products': products})

# View for managing categories
@login_required
def manage_categories(request):
    categories = Category.objects.all()
    return render(request, 'store/manage_categories.html', {'categories': categories})

# View for managing orders
@login_required
def manage_orders(request):
    orders = Order.objects.all()
    return render(request, 'store/manage_orders.html', {'orders': orders})

# View for managing reviews
@login_required
def manage_reviews(request):
    reviews = Review.objects.all()
    return render(request, 'store/manage_reviews.html', {'reviews': reviews})

# View for managing users
@login_required
def manage_users(request):
    users = User.objects.all()
    return render(request, 'store/manage_users.html', {'users': users})

# View for managing contacts
@login_required
def manage_contacts(request):
    contacts = Contact.objects.all()
    return render(request, 'store/manage_contacts.html', {'contacts': contacts})

    #--------------------------add---------------------
    # store/views.py
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import ProductForm  # You will create this form below
from .models import Product  # Assuming you have a Product model

def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)  # Include request.FILES for handling images
        if form.is_valid():
            form.save()
            return redirect('store:manage_products')  # Redirect to product list page
    else:
        form = ProductForm()
    return render(request, 'store/add_product.html', {'form': form})
#-----------------edit--------------------------
from django.shortcuts import render, get_object_or_404, redirect
from .forms import ProductForm
from .models import Product

def edit_product(request, product_id):
    # Fetch the product instance
    product = get_object_or_404(Product, id=product_id)

    # Initialize the form with existing product data
    form = ProductForm(request.POST or None, instance=product)

    if request.method == 'POST' and form.is_valid():
        form.save()  # Save the updated product
        return redirect('store:manage_products')  # Redirect to the product management page

    return render(request, 'store/edit_product.html', {'form': form})

#---------------------delete-----------------------
# store/views.py
from django.shortcuts import get_object_or_404, redirect
from .models import Product
from django.contrib.auth.decorators import login_required

@login_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        product.delete()
        return redirect('store:manage_products')  # Redirect to manage products page after deletion
    return render(request, 'store/delete_product.html', {'product': product})
#----------------categery-------------
from django.shortcuts import render, get_object_or_404, redirect
from .models import Category
from .forms import CategoryForm

def edit_category(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    
    if request.method == 'POST':
        # Handle form submission and update the category
        title = request.POST['title']
        slug = request.POST['slug']
        description = request.POST['description']
        category_image = request.FILES.get('category_image', category.category_image)  # Use existing if not provided
        is_active = 'is_active' in request.POST
        is_featured = 'is_featured' in request.POST
        
        category.title = title
        category.slug = slug
        category.description = description
        category.category_image = category_image
        category.is_active = is_active
        category.is_featured = is_featured
        category.save()

        return redirect('store:manage_categories')  # Redirect to the category management page after saving
    else:
        return render(request, 'store/edit_category.html', {'category': category})

# Delete category
def delete_category(request, pk):
    category = get_object_or_404(Category, pk=pk)
    
    if request.method == 'POST':
        category.delete()
        return redirect('store:manage_categories')
    
    return render(request, 'store/delete_category_confirm.html', {'category': category})

from django.shortcuts import render, redirect
from django.utils.text import slugify
from .models import Category

def add_category(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        slug = slugify(request.POST.get('slug'))  # Generate slug from the provided title or input
        description = request.POST.get('description')
        is_active = request.POST.get('is_active') == 'on'  # Check if checkbox is checked
        is_featured = request.POST.get('is_featured') == 'on'  # Check if checkbox is checked
        category_image = request.FILES.get('category_image')

        # Create and save the new category
        Category.objects.create(
            title=title,
            slug=slug,
            description=description,
            is_active=is_active,
            is_featured=is_featured,
            category_image=category_image
        )

        return redirect('store:manage_categories')  # Redirect to the manage categories page

    return render(request, 'store/add_category.html')
#--------------------order-------------------------------
from django.shortcuts import render, get_object_or_404, redirect
from .models import Order
from .forms import OrderForm


# View to add an order
def add_order(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('store:manage_orders')
    else:
        form = OrderForm()
    return render(request, 'store/add_order.html', {'form': form})

# View to edit an order
def edit_order(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if request.method == 'POST':
        form = OrderForm(request.POST, instance=order)
        if form.is_valid():
            form.save()
            return redirect('store:manage_orders')
    else:
        form = OrderForm(instance=order)
    return render(request, 'store/edit_order.html', {'form': form, 'order': order})

# View to delete an order
def delete_order(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if request.method == 'POST':
        order.delete()
        return redirect('store:manage_orders')
    return render(request, 'store/delete_order.html', {'order': order})
from django.shortcuts import render, redirect
from .forms import ReviewForm
from django.contrib import messages

# Add Review View
def add_review(request):
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Review added successfully!")
            return redirect('store:manage_reviews')
    else:
        form = ReviewForm()
    
    return render(request, 'store/add_review.html', {'form': form})

from django.shortcuts import render, get_object_or_404, redirect
from django.http import Http404
from .models import Review
from .forms import ReviewForm  # Assuming you have a form for reviews
from django.contrib import messages

# Edit Review View
def edit_review(request, review_id):
    review = get_object_or_404(Review, id=review_id)
    
    if request.method == 'POST':
        form = ReviewForm(request.POST, instance=review)
        if form.is_valid():
            form.save()
            messages.success(request, "Review updated successfully!")
            return redirect('store:manage_reviews')
    else:
        form = ReviewForm(instance=review)
    
    return render(request, 'store/edit_review.html', {'form': form, 'review': review})

# Delete Review View
def delete_review(request, review_id):
    review = get_object_or_404(Review, id=review_id)
    
    if request.method == 'POST':
        review.delete()
        messages.success(request, "Review deleted successfully!")
        return redirect('store:manage_reviews')
    
    return render(request, 'store/delete_review.html', {'review': review})
#-----------------------------------user------------------------
from django.shortcuts import render, get_object_or_404, redirect
from .models import User, Profile
from .forms import UserForm

def edit_user(request, user_id):
    user = get_object_or_404(User, id=user_id)
    
    # Try to get the Profile, or create a new one if it doesn't exist
    profile, created = Profile.objects.get_or_create(user=user)
    
    if request.method == 'POST':
        user_form = UserForm(request.POST, instance=user)
        if user_form.is_valid():
            user_form.save()
            profile.phone_number = request.POST.get('phone_number')
            profile.address = request.POST.get('address')
            profile.save()
            return redirect('store:manage_users')  # Redirect to another page after saving
            
    else:
        user_form = UserForm(instance=user)  # Populate form with existing data

    # Pass date_joined for the currently logged-in user
    date_joined = request.user.date_joined if request.user.is_authenticated else None
    
    return render(request, 'store/edit_user.html', {'user_form': user_form, 'profile': profile, 'date_joined': date_joined})


def delete_user(request, user_id):
    user = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        user.delete()
        return redirect('store:manage_users')  # Redirect to user management page
    return render(request, 'store/delete_user_confirmation.html', {'user': user})

from django.http import JsonResponse
from .recommendation import get_recommendations

def recommend_products(request, user_id):
    recommendations = get_recommendations(user_id)
    return JsonResponse({'recommendations': recommendations})

    from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def admin_profile_view(request):
    # Your code to render the admin profile page
    return render(request, 'store/admin_profile.html')

    

