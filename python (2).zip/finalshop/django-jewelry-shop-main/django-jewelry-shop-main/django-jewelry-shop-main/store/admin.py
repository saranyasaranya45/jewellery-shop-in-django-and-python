from django.contrib import admin
from .models import Product, Category, Order, Review, User, Contact

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'price', 'category', 'is_active', 'created_at')
    search_fields = ('title', 'sku')
    list_filter = ('category', 'is_active')

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('title', 'is_active', 'created_at')
    search_fields = ('title',)

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('user', 'product', 'quantity', 'status', 'ordered_date')
    list_filter = ('status',)

from django.contrib import admin
from .models import Review

from django.contrib import admin
from .models import Review

class ReviewAdmin(admin.ModelAdmin):
    list_display = ('get_reviewer_username', 'product', 'rating', 'created_at',)
    
    def get_reviewer_username(self, obj):
        return obj.reviewer.username
    get_reviewer_username.short_description = 'Reviewer'  # Optional: Change column header



@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'message')

# Ensure that User management is also handled in the Django admin.
