# myapp/backends/custom_smtp.py

from django.core.mail.backends.smtp import EmailBackend

class CustomEmailBackend(EmailBackend):
    def open(self):
        # Override to remove keyfile argument if present
        try:
            return super().open()
        except TypeError as e:
            if "keyfile" in str(e):
                # Retry without keyfile if TypeError is due to keyfile argument
                self.connection.starttls()
                self.connection.login(self.username, self.password)
                return True
            raise
