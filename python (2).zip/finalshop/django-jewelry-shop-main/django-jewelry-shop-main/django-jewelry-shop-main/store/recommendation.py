import pandas as pd
from sklearn.neighbors import NearestNeighbors
import numpy as np

# Sample data (you'd replace this with actual database queries)
data = {
    'user_id': [1, 1, 2, 2, 3, 3],
    'product_id': [101, 102, 101, 103, 102, 104],
}
df = pd.DataFrame(data)

# Create a user-product matrix
user_product_matrix = df.pivot(index='user_id', columns='product_id', values='product_id').fillna(0)
user_product_matrix[user_product_matrix > 0] = 1  # Convert to binary interaction matrix

# Train a Nearest Neighbors model
model = NearestNeighbors(metric='cosine', algorithm='brute')
model.fit(user_product_matrix)

def get_recommendations(user_id, n_recommendations=5):
    distances, indices = model.kneighbors(user_product_matrix.loc[user_id].values.reshape(1, -1), n_neighbors=n_recommendations+1)
    recommendations = user_product_matrix.index[indices.flatten()].tolist()
    recommendations.remove(user_id)  # Exclude the original user
    return recommendations
