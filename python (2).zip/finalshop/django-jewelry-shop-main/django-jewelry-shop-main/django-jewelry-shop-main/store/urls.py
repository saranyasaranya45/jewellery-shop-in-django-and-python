from store.forms import LoginForm, PasswordChangeForm, PasswordResetForm, SetPasswordForm
from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from .views import blog_view, contact_view  # Ensure you import the views
from .views import success_view  # Corrected import
from django.urls import path
from django.contrib.auth import views as auth_views
app_name = 'store'


urlpatterns = [
    path('', views.home, name="home"),
    # URL for Cart and Checkout
    path('blog/', blog_view, name='blog'),  # This line should be correct
    path('contact/', views.contact_view, name='contact'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('thank-you/', views.thank_you, name='thank-you'),
    path('admin-login/', views.admin_login, name='admin_login'),
    path('submit-contact/', views.submit_contact, name='submit-contact'),
    path('success/', success_view, name='success'),
    path('add-to-cart/', views.add_to_cart, name="add-to-cart"),
    path('remove-cart/<int:cart_id>/', views.remove_cart, name="remove-cart"),
    path('plus-cart/<int:cart_id>/', views.plus_cart, name="plus-cart"),
    path('minus-cart/<int:cart_id>/', views.minus_cart, name="minus-cart"),
    path('cart/', views.cart, name="cart"),
    path('checkout/', views.checkout, name='checkout'),
    path('payment/<int:order_id>/', views.payment, name='payment'),
    path('order-confirmation/<int:order_id>/', views.order_confirmation, name='order_confirmation'),
    path('orders/', views.orders, name="orders"),
    path('admin_manage_products/', views.manage_products, name='manage_products'),
    path('admin_manage_categories/', views.manage_categories, name='manage_categories'),
    path('admin_manage_orders/', views.manage_orders, name='manage_orders'),
    path('admin_manage_reviews/', views.manage_reviews, name='manage_reviews'),
    path('admin_manage_users/', views.manage_users, name='manage_users'),
    path('admin_manage_contacts/', views.manage_contacts, name='manage_contacts'),
    path('add-product/', views.add_product, name='add_product'),
    path('edit-product/<int:product_id>/', views.edit_product, name='edit_product'),
    path('delete-product/<int:product_id>/', views.delete_product, name='delete_product'),
    path('add_category/', views.add_category, name='add_category'),  # Add this URL pattern
    path('category/edit/<int:category_id>/', views.edit_category, name='edit_category'),
    path('category/delete/<int:pk>/', views.delete_category, name='delete_category'),
    path('add_order/', views.add_order, name='add_order'),  # Ensure this line is present
    path('orders/edit/<int:order_id>/', views.edit_order, name='edit_order'),
    path('orders/delete/<int:order_id>/', views.delete_order, name='delete_order'),
    path('reviews/edit/<int:review_id>/', views.edit_review, name='store_review_change'),
    path('reviews/delete/<int:review_id>/', views.delete_review, name='store_review_delete'),
    path('reviews/add/', views.add_review, name='add_review'),
    path('user/edit/<int:user_id>/', views.edit_user, name='user_edit'),
    path('user/delete/<int:user_id>/', views.delete_user, name='user_delete'),
    path('profile/', views.admin_profile_view, name='admin_profile'),

    

    #URL for Products
    path('product/<slug:slug>/', views.detail, name="product-detail"),
    path('categories/', views.all_categories, name="all-categories"),
    path('logout/', views.logout_view, name='logout'),
    path('<slug:slug>/', views.category_products, name="category-products"),
    path('shop/', views.shop, name="shop"),


    # URL for Authentication
    path('accounts/register/', views.RegistrationView.as_view(), name="register"),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='account/login.html', authentication_form=LoginForm), name="login"),
    path('accounts/profile/', views.profile, name="profile"),
    path('accounts/add-address/', views.AddressView.as_view(), name="add-address"),
    path('accounts/remove-address/<int:id>/', views.remove_address, name="remove-address"),
    path('accounts/password-change/', auth_views.PasswordChangeView.as_view(template_name='account/password_change.html', form_class=PasswordChangeForm, success_url='/accounts/password-change-done/'), name="password-change"),
    path('accounts/password-change-done/', auth_views.PasswordChangeDoneView.as_view(template_name='account/password_change_done.html'), name="password-change-done"),

    path('accounts/password-reset/', auth_views.PasswordResetView.as_view(template_name='account/password_reset.html', form_class=PasswordResetForm, success_url='/accounts/password-reset/done/'), name="password-reset"), # Passing Success URL to Override default URL, also created password_reset_email.html due to error from our app_name in URL
    path('accounts/password-reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='account/password_reset_done.html'), name="password_reset_done"),
    path('accounts/password-reset-confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='account/password_reset_confirm.html', form_class=SetPasswordForm, success_url='/accounts/password-reset-complete/'), name="password_reset_confirm"), # Passing Success URL to Override default URL
    path('accounts/password-reset-complete/', auth_views.PasswordResetCompleteView.as_view(template_name='account/password_reset_complete.html'), name="password_reset_complete"),
    path('api/recommend/<int:user_id>/', views.recommend_products, name='recommend_products'),

    path('test/', views.test, name="test"),
    
    path('product/<slug:slug>/', views.product_detail, name='product_detail'),
    path('product/<slug:slug>/add-review/', views.product_detail, name='add_review'),
    path('product/<int:product_id>/submit-review/', views.submit_review, name='submit-review'),
    path('add-to-wishlist/<int:product_id>/', views.add_to_wishlist, name='add-to-wishlist'),
    path('admin/deactivate-user/<int:user_id>/', views.deactivate_user, name='deactivate_user'),



]  